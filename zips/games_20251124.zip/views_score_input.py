from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
import json

from apps.games.models import Game
from apps.scores.models import Pitch

@require_http_methods(["GET"])
def score_input(request, pk):
    """
    Render the score input screen for a game.
    Initial state: show one empty row and recent pitches (up to 10) for context.
    """
    game = get_object_or_404(Game, pk=pk)
    recent_pitches = Pitch.objects.filter(game=game).order_by("-id")[:10]
    # Render template; front-end will manage rows (initial 1 empty row)
    return render(request, "games/score_input/index.html", {
        "game": game,
        "recent_pitches": list(recent_pitches[::-1]),  # oldest first
    })

@csrf_exempt
@require_http_methods(["POST"])
def save_pitch(request, pk):
    """
    Simple AJAX endpoint to save a pitch record.
    Expects JSON: {
        "inning": 1, "top_bottom":"top",
        "batter_id": 12, "pitcher_id": 5,
        "pitch_result": "ball", "batter_result": "hit", "runner_action": "advance_1"
    }
    """
    try:
        payload = json.loads(request.body.decode("utf-8"))
    except Exception:
        return HttpResponseBadRequest("invalid json")

    game = get_object_or_404(Game, pk=pk)

    # Minimal required fields
    inning = payload.get("inning")
    top_bottom = payload.get("top_bottom", "top")
    batter_id = payload.get("batter_id")
    pitcher_id = payload.get("pitcher_id")
    pitch_result = payload.get("pitch_result")
    batter_result = payload.get("batter_result")
    runner_action = payload.get("runner_action", "")

    # Basic validation (can be extended)
    if inning is None or batter_id is None or pitcher_id is None or pitch_result is None:
        return HttpResponseBadRequest("missing required fields")

    # Create Pitch record
    pitch = Pitch.objects.create(
        game=game,
        inning=inning,
        top_bottom=top_bottom,
        batter_id=batter_id,
        pitcher_id=pitcher_id,
        pitch_result=pitch_result,
        batter_result=batter_result or "",
        runner_action=runner_action or "",
    )

    return JsonResponse({"ok": True, "pitch_id": pitch.id})
