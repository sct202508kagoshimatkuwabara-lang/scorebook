from . import views
from django.urls import path
from . import views_score_input as views_score_input  # ensure this module is importable

app_name = "games"

urlpatterns = [
    path("", views.game_list, name="game_list"),
    path("create/", views.game_add, name="game_add"),
    path("<int:pk>/edit/", views.game_edit, name="game_edit"),
    path("<int:pk>/delete/", views.game_delete, name="game_delete"),

    # ★ スコア入力トップ
    path("<int:pk>/score/", views.score_top, name="score_top"),

    # ★ メンバー表入力（先攻/後攻ともにここ）
    #   ※ HTML のリンクは games:lineup を使っているため name="lineup" が必須！
    path("<int:game_id>/lineup/<int:team_id>/", views.lineup_add, name="lineup_add"),

    # ★ 投球入力（まだ仮）
    path("<int:pk>/pitch/", views.pitch_start, name="pitch_start"),

    path("<int:pk>/score_input/", views_score_input.score_input, name="score_input"),
    path("<int:pk>/score_input/save/", views_score_input.save_pitch, name="score_input_save"),

]