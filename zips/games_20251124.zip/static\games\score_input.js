document.addEventListener("DOMContentLoaded", function(){
  const tbody = document.getElementById("pitch-tbody");
  const addBtn = document.getElementById("add-row");
  let rowCount = tbody.querySelectorAll(".pitch-row").length;

  function createRow(index){
    const tr = document.createElement("tr");
    tr.className = "pitch-row";
    tr.dataset.rowIndex = index;

    tr.innerHTML = `
      <td>
        <select class="inning">
          ${[...Array(20)].map((_, i) =>
            `<option value="${i+1}">${i+1}回</option>`
          ).join("")}
        </select>
        <select class="top_bottom">
          <option value="top">表</option>
          <option value="bottom">裏</option>
        </select>
      </td>

      <td><a href="#" class="edit-defense">守備メンバー変更</a></td>
      <td><a href="#" class="edit-batting">打席メンバー変更</a></td>

      <td>
        <select class="pitch_result">
          <option value="ball">Ball</option>
          <option value="strike">Strike</option>
          <option value="foul">Foul</option>
          <option value="out">Out</option>
          <option value="hit">Hit</option>
        </select>
      </td>

      <td>
        <select class="batter_result">
          <option value="">---</option>
          <option value="k">三振</option>
          <option value="bb">四球</option>
          <option value="single">安打</option>
          <option value="double">二塁打</option>
          <option value="hr">本塁打</option>
          <option value="g">ゴロアウト</option>
          <option value="f">フライアウト</option>
        </select>
      </td>

      <td>
        <select class="runner_action">
          <option value="">なし</option>
          <option value="advance_1">1塁へ</option>
          <option value="advance_2">2塁へ</option>
          <option value="advance_3">3塁へ</option>
          <option value="home">ホームイン</option>
        </select>
      </td>

      <td>
        <button class="save-row">保存</button>
        <button class="delete-row">削除</button>
      </td>
    `;

    attachRowHandlers(tr);
    return tr;
  }

  function attachRowHandlers(tr){
    tr.querySelector(".delete-row").addEventListener("click", function(e){
      e.preventDefault();
      tr.remove();
    });

    tr.querySelector(".save-row").addEventListener("click", function(e){
      e.preventDefault();
      saveRow(tr);
    });
  }

  function saveRow(tr){
    const data = {
      inning: parseInt(tr.querySelector(".inning").value),
      top_bottom: tr.querySelector(".top_bottom").value,
      batter_id: null,
      pitcher_id: null,
      pitch_result: tr.querySelector(".pitch_result").value,
      batter_result: tr.querySelector(".batter_result").value,
      runner_action: tr.querySelector(".runner_action").value
    };

    const pk = window.SCORE_INPUT && window.SCORE_INPUT.game_pk;

    fetch(`/games/${pk}/score_input/save/`, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(data)
    })
    .then(r => r.json())
    .then(resp => {
      alert("保存しました (id="+resp.pitch_id+")");
    });
  }

  // 初期行のイベント付与
  tbody.querySelectorAll(".pitch-row").forEach(attachRowHandlers);

  addBtn.addEventListener("click", function(){
    rowCount += 1;
    const newRow = createRow(rowCount);
    tbody.appendChild(newRow);
  });
});
